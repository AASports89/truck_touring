CREATE VIEW INFORMATION_SCHEMA.SCHEMATA
AS
SELECT
	DB_NAME()			AS CATALOG_NAME,
	name				AS SCHEMA_NAME,
	USER_NAME(principal_id)		AS SCHEMA_OWNER,
	convert(sysname, null)		AS DEFAULT_CHARACTER_SET_CATALOG,
	convert(sysname, null) collate catalog_default	AS DEFAULT_CHARACTER_SET_SCHEMA,
	convert(sysname, DATABASEPROPERTYEX(DB_NAME(), 'sqlcharsetname'))
					AS DEFAULT_CHARACTER_SET_NAME
FROM
	sys.schemas
go

