CREATE VIEW INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
AS
SELECT
	DB_NAME()				AS CONSTRAINT_CATALOG,
	SCHEMA_NAME(f.schema_id)		AS CONSTRAINT_SCHEMA,
	f.name					AS CONSTRAINT_NAME,
	DB_NAME()				AS UNIQUE_CONSTRAINT_CATALOG,
	SCHEMA_NAME(t.schema_id)		AS UNIQUE_CONSTRAINT_SCHEMA,
	i.name					AS UNIQUE_CONSTRAINT_NAME,
	convert(varchar(7), 'SIMPLE')	AS MATCH_OPTION,
	convert(varchar(11), CASE f.update_referential_action
		WHEN 0 THEN 'NO ACTION'
		WHEN 1 THEN 'CASCADE'
		WHEN 2 THEN 'SET NULL'
		WHEN 3 THEN 'SET DEFAULT' END) AS UPDATE_RULE,
	convert(varchar(11), CASE f.delete_referential_action
		WHEN 0 THEN 'NO ACTION'
		WHEN 1 THEN 'CASCADE'
		WHEN 2 THEN 'SET NULL'
		WHEN 3 THEN 'SET DEFAULT' END) AS DELETE_RULE
FROM		
	sys.foreign_keys f
	LEFT JOIN sys.indexes i ON i.object_id = f.referenced_object_id AND i.index_id = f.key_index_id
	LEFT JOIN sys.tables t ON t.object_id = f.referenced_object_id
go

